package com.skloch.game.AchievementSystem.Achievements;

public class DistanceTraveledAchievement extends Achievements {
    public DistanceTraveledAchievement() {
        super("Distance Traveled", "Travel a certain distance in the game!", new int[]{5000, 25000, 75000, 125000});
    }
}
