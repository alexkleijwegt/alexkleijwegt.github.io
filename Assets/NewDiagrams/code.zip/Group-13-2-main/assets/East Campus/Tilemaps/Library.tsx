<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Library" tilewidth="24" tileheight="24" tilecount="312" columns="24">
 <image source="../Textures/Library.png" width="589" height="330"/>
</tileset>
