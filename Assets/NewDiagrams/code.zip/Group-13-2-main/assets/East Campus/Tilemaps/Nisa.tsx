<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Nisa" tilewidth="24" tileheight="24" tilecount="108" columns="12">
 <image source="../Textures/Nisa.png" width="306" height="216"/>
</tileset>
