package com.skloch.game.AchievementSystem.Achievements;

public class FirstTimeSleptAchievement extends Achievements {

    public FirstTimeSleptAchievement() {
        super("First Time Slept", "Sleep for the first time!", new int[]{1});
    }
}
