package com.skloch.game.AchievementSystem.Achievements;

public class FirstTimeRecreationAchievement extends Achievements {

    public FirstTimeRecreationAchievement() {
        super("First Recreation Break", "Do a recreational activity for the first time!", new int[]{1});
    }
}
