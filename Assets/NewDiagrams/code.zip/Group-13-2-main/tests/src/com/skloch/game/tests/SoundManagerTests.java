package com.skloch.game.tests;

import com.skloch.game.SoundManager;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(GdxTestRunner.class)

public class SoundManagerTests {

    private static final double DELTA = 0.00001f;

    @Test
    public void changeMusicVolumeTo0() {
        SoundManager soundmanager = new SoundManager();
        soundmanager.setMusicVolume(0);

        assertEquals(0, soundmanager.getMusicVolume(), DELTA);
    }

    @Test
    public void changeSfxVolumeTo0() {
        SoundManager soundmanager = new SoundManager();
        soundmanager.setSfxVolume(0);

        assertEquals(0, soundmanager.getSfxVolume(), DELTA);
    }

    @Test
    public void changeMusicVolumeToFull() {
        SoundManager soundmanager = new SoundManager();
        soundmanager.setMusicVolume(1.0f);

        assertEquals(1.0f, soundmanager.getMusicVolume(), DELTA);
    }

    @Test
    public void changeSfxVolumeToFull() {
        SoundManager soundmanager = new SoundManager();
        soundmanager.setSfxVolume(1.0f);

        assertEquals(1.0f, soundmanager.getSfxVolume(), DELTA);
    }

}
