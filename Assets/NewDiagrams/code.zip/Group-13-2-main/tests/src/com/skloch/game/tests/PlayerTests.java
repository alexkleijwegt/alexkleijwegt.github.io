package com.skloch.game.tests;
import com.skloch.game.GameObject;
import com.skloch.game.Player;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(GdxTestRunner.class)

public class PlayerTests {

    public float DELTA = 0.00001f;

    @Test
    public void testPlayerSetUp() {
        Player player = new Player("avatar1");
        assertNotNull(player.sprite);
        assertNotNull(player.feet);
        assertNotNull(player.eventHitbox);
        assertNotNull(player.collidables);
        assertEquals(2, player.direction);
    }

    @Test
    public void testPlayerSpriteSetUp() {
        Player player = new Player("avatar1");
        float expectedX = 0;
        float expectedY = 0;
        float expectedWidth = 17*player.scale;
        float expectedHeight = 28*player.scale;
        assertEquals(expectedX, player.sprite.getX(), DELTA);
        assertEquals(expectedY, player.sprite.getY(), DELTA);
        assertEquals(expectedWidth, player.sprite.getWidth(), DELTA);
        assertEquals(expectedHeight, player.sprite.getHeight(), DELTA);
    }

    @Test
    public void testPlayerFeetSetUp() {
        Player player = new Player("avatar1");
        float expectedX = 4*player.scale;
        float expectedY = 0;
        float expectedWidth = 9*player.scale;
        float expectedHeight = 7*player.scale;
        assertEquals(expectedX, player.feet.getX(), DELTA);
        assertEquals(expectedY, player.feet.getY(), DELTA);
        assertEquals(expectedWidth, player.feet.getWidth(), DELTA);
        assertEquals(expectedHeight, player.feet.getHeight(), DELTA);
    }

    @Test
    public void testPlayerEventHitboxSetUp() {
        Player player = new Player("avatar1");
        float expectedX = player.sprite.getX() - (player.sprite.getWidth() * 2.2f - player.sprite.getWidth()) / 2;
        float expectedY = player.sprite.getY() - (player.sprite.getHeight() * 1.7f - player.sprite.getHeight()) / 2;
        float expectedWidth = player.sprite.getWidth() * 2.2f;
        float expectedHeight = player.sprite.getHeight() * 1.7f;
        assertEquals(expectedX, player.eventHitbox.getX(), DELTA);
        assertEquals(expectedY, player.eventHitbox.getY(), DELTA);
        assertEquals(expectedWidth, player.eventHitbox.getWidth(), DELTA);
        assertEquals(expectedHeight, player.eventHitbox.getHeight(), DELTA);
    }

    @Test
    public void testIsPlayerMoving() {
        Player player = new Player("avatar1");
        player.setMoving(true);
        assertTrue(player.isMoving());

    }

    @Test
    public void testIsPlayerNotMoving() {
        Player player = new Player("avatar1");
        player.setMoving(false);
        assertFalse(player.isMoving());

    }

    @Test
    public void testFrozen() {
        Player player = new Player("avatar1");
        player.setFrozen(true);
        player.move(1);
        assertTrue("Player should be frozen", player.isFrozen());
        assertFalse("Player should not move", player.isMoving());
    }

    @Test
    public void testMoveLeft() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, true, false, false, false);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should not change", old_y, new_y, 0.001f);
        assertEquals("X-value should decrease", old_x-player.speed, new_x, 0.001f);
        assertEquals("Direction should change to face the left", 3, player.direction);
    }

    @Test
    public void testMoveRight() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, false, true, false, false);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should not change", old_y, new_y, 0.001f);
        assertEquals("X-value should increase", old_x+player.speed, new_x, 0.001f);
        assertEquals("Direction should change to face the right", 1, player.direction);
    }

    @Test
    public void testMoveUp() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, false, false, true, false);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should increase", old_y+player.speed, new_y, 0.001f);
        assertEquals("X-value should not change", old_x, new_x, 0.001f);
        assertEquals("Direction should change to face up", 0, player.direction);
    }

    @Test
    public void testMoveDown() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, false, false, false, true);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should decrease", old_y-player.speed, new_y, 0.001f);

        assertEquals("X-value should not change", old_x, new_x, 0.001f);
        assertEquals("Direction should change to face down", 2, player.direction);
    }

    @Test
    public void testMoveDownAndUp() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, false, false, true, true);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should not change", old_y, new_y, 0.001f);
        assertEquals("X-value should not change", old_x, new_x, 0.001f);
        assertEquals("Direction should face down", 2, player.direction);
    }

    @Test
    public void testLeftAndRight() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, true, true, false, false);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should not change", old_y, new_y, 0.001f);
        assertEquals("X-value should not change", old_x, new_x, 0.001f);
        assertEquals("Direction should face right", 1, player.direction);
    }
    @Test
    public void testLeftAndUp() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, true, false, true, false);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should decrease", old_y+ player.speed, new_y, 0.001f);
        assertEquals("X-value should decrease", old_x- player.speed, new_x, 0.001f);
        assertEquals("Direction should face up", 0, player.direction);
    }

    @Test
    public void testLeftAndDown() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, true, false, false, true);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should decrease", old_y- player.speed, new_y, 0.001f);
        assertEquals("X-value should decrease", old_x- player.speed, new_x, 0.001f);
        assertEquals("Direction should face down", 2, player.direction);
    }

    @Test
    public void testRightAndUp() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, false, true, true, false);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should increase", old_y+ player.speed, new_y, 0.001f);
        assertEquals("X-value should increase", old_x+ player.speed, new_x, 0.001f);
        assertEquals("Direction should face up", 0, player.direction);
    }

    @Test
    public void testRightAndDown() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, false, true, false, true);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should decrease", old_y- player.speed, new_y, 0.001f);
        assertEquals("X-value should increase", old_x+ player.speed, new_x, 0.001f);
        assertEquals("Direction should face down", 2, player.direction);
    }

    @Test
    public void testMoveDownUpLeftRight() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, true, true, true, true);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should not change", old_y, new_y, 0.001f);
        assertEquals("X-value should not change", old_x, new_x, 0.001f);
        assertEquals("Direction should face down", 2, player.direction);
    }

    @Test
    public void testMoveNowhere() {
        PlayerTestFake player = new PlayerTestFake("avatar1");
        float old_x = player.getX();
        float old_y = player.getY();
        player.move(1, false, false, false, false);
        float new_x = player.getX();
        float new_y = player.getY();
        assertEquals("Y-value should not change", old_y, new_y, 0.001f);
        assertEquals("X-value should not change", old_x, new_x, 0.001f);
        assertEquals("Direction should face down", 2, player.direction);
    }

    @Test
    public void testNearEnoughToInteract() {
        Player player = new Player("avatar1");
        GameObject gameObject1 = new GameObject(0, 0, 10, 10);
        gameObject1.put("event", "test");
        player.addCollidable(gameObject1);
        player.setPos(0, 0);
        player.move(1);
        assertTrue(player.nearObject());
    }
    @Test
    public void testJustNearEnoughToInteractX() {
        Player player = new Player("avatar1");
        float width = 10f;
        float height = 10f;
        float Xlimit = (player.sprite.getX() - (player.sprite.getWidth() * 2.2f - player.sprite.getWidth()) / 2);
        GameObject gameObject1 = new GameObject(Xlimit, 0, width, height);
        gameObject1.put("event", "test");
        player.addCollidable(gameObject1);
        player.setPos(0, 0);
        player.move(1);
        assertTrue(player.nearObject());
    }
    @Test
    public void testJustFarEnoughToNotInteractX() {
        Player player = new Player("avatar1");
        float width = 10f;
        float height = 10f;
        GameObject gameObject1 = new GameObject(0, 0, width, height);
        float Xlimit = (player.sprite.getX() - (player.sprite.getWidth() * 2.2f - player.sprite.getWidth()) / 2)-width;
        gameObject1.put("event", "test");
        player.addCollidable(gameObject1);
        player.setPos(Xlimit, 0);
        player.move(1);
        assertTrue(player.nearObject());
    }

    @Test
    public void testJustNearEnoughToInteractY() {
        Player player = new Player("avatar1");
        float width = 10f;
        float height = 10f;
        float Ylimit = (float)(player.sprite.getY() - (player.sprite.getHeight() * 1.7 - player.sprite.getHeight()) / 2);
        GameObject gameObject1 = new GameObject( 0, Ylimit, width, height);
        gameObject1.put("event", "test");
        player.addCollidable(gameObject1);
        player.setPos(0, 0);
        player.move(1);
        assertTrue(player.nearObject());
    }
    @Test
    public void testJustFarEnoughToNotInteractY() {
        Player player = new Player("avatar1");
        float width = 10f;
        float height = 10f;
        GameObject gameObject1 = new GameObject(0, 0, width, height);
        float Xlimit = (player.sprite.getY() - (player.sprite.getHeight() * 1.7f - player.sprite.getHeight()) / 2)-height;
        gameObject1.put("event", "test");
        player.addCollidable(gameObject1);
        player.setPos(Xlimit, 0);
        player.move(1);
        assertTrue(player.nearObject());
    }

    /*
    @Test
    public void testCollision() {
        Player player = new Player("avatar1");
        player.setFrozen(false);
        player.setPos(50, 50);
        player.move(1);
        GameObject gameObject1 = new GameObject(0, 0, 5, 5);
        player.addCollidable(gameObject1);
        player.setPos(0, 0);
        player.move(1);
        assertTrue(player.feet.overlaps(new Rectangle(0, 0, 5, 5)));

    }
     */

}
