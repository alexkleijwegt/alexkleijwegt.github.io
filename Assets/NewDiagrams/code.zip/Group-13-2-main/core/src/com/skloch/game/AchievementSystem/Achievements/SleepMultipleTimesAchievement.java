package com.skloch.game.AchievementSystem.Achievements;

public class SleepMultipleTimesAchievement extends Achievements {
    public SleepMultipleTimesAchievement() {
        super("Sleep Multiple Times", "Sleep multiple times!", new int[]{1, 2, 3, 5});
    }
}