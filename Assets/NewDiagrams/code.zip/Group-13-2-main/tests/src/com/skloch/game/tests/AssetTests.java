package com.skloch.game.tests;

import com.badlogic.gdx.Gdx;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertTrue;

@RunWith(GdxTestRunner.class)

public class AssetTests {

  @Test
  public void testComputerScienceExists() {
    assertTrue("The assets for the Computer Science Building exist",
            Gdx.files.internal("../assets/East Campus/Textures/compsci.png").exists() &&
                    Gdx.files.internal("../assets/East Campus/Tilemaps/compsci.tsx").exists()
    );
  }

  @Test
  public void testConstantineExists() {
    assertTrue("The assets for the Constantine College exist",
            Gdx.files.internal("../assets/East Campus/Textures/Constantine.png").exists() &&
                    Gdx.files.internal("../assets/East Campus/Tilemaps/Constantine.tsx").exists()
    );
  }

    @Test
    public void testPiazzaExists() {
      assertTrue("The assets for the Piazza exist",
              Gdx.files.internal("../assets/East Campus/Textures/piazza.png").exists() &&
                      Gdx.files.internal("../assets/East Campus/Tilemaps/piazza.tsx").exists()
      );
    }

    @Test
    public void testRonCookeHubExists() {
      assertTrue("The assets for the Ron Cooke Hub exists",
              Gdx.files.internal("../assets/East Campus/Textures/RCH.png").exists() &&
                      Gdx.files.internal("../assets/East Campus/Tilemaps/RCH.tsx").exists()
      );
    }

  @Test
  public void testBackgroundTexturesExist() {
    assertTrue("The assets for background textures exist",
            Gdx.files.internal("../assets/East Campus/Textures/StarRealmsCozyForestPack24x24.png").exists() &&
                    Gdx.files.internal("../assets/East Campus/Tilemaps/StarRealmsCozyForestPack24x24.tsx").exists()
    );
  }

  @Test
  public void testMusicExists() {
    assertTrue("The assets for music exist",
            Gdx.files.internal("../assets/Music/OverworldMusic.mp3").exists() &&
                    Gdx.files.internal("../assets/Music/Streetlights.ogg").exists()
    );
  }

  @Test
  public void testFootstepSoundsExists() {
    assertTrue("The assets for walking sounds exist",
            Gdx.files.internal("../assets/Sounds/footstep1.ogg").exists() &&
                    Gdx.files.internal("../assets/Sounds/footstep1 grass.ogg").exists() &&
                    Gdx.files.internal("../assets/Sounds/footstep2.ogg").exists() &&
                    Gdx.files.internal("../assets/Sounds/footstep2 grass.ogg").exists() &&
                    Gdx.files.internal("../assets/Sounds/Walking.wav").exists()
    );
  }

  @Test
  public void testDialogueSoundsExists() {
    assertTrue("The assets for dialogue sounds exist",
            Gdx.files.internal("../assets/Sounds/DialogueOpen.wav").exists() &&
                    Gdx.files.internal("../assets/Sounds/DialogueOption.wav").exists()
    );
  }

  @Test
  public void testButtonSoundsExists() {
    assertTrue("The assets for button sounds exist",
            Gdx.files.internal("../assets/Sounds/Button.wav").exists()
    );
  }

  @Test
  public void testPauseExists() {
    assertTrue("The assets for pause sounds exist",
            Gdx.files.internal("../assets/Sounds/Pause01.wav").exists()
    );
  }

  @Test
  public void testAvatar1Exists() {
    assertTrue("The assets for avatar1 exist",
            Gdx.files.internal("../assets/Sprites/avatar1.png").exists()
    );
  }

  @Test
  public void testAvatar2Exists() {
    assertTrue("The assets for avatar2 exist",
            Gdx.files.internal("../assets/Sprites/avatar2.png").exists()
    );
  }

  @Test
  public void testPlayerSpritesAtlasExists() {
    assertTrue("The atlas for player_sprite exists",
            Gdx.files.internal("../assets/Sprites/Player/player_sprites.atlas").exists()
    );
    assertTrue("The png for player_sprite exists",
            Gdx.files.internal("../assets/Sprites/Player/player_sprites.png").exists()
    );
  }



}
