package com.skloch.game.tests;
import com.skloch.game.AchievementSystem.Achievements.FirstTimeSleptAchievement;
import com.skloch.game.AchievementSystem.Achievements.SleepMultipleTimesAchievement;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(GdxTestRunner.class)
public class SleepAchievementsTests {
    FirstTimeSleptAchievement sleptOnce = new FirstTimeSleptAchievement();
    SleepMultipleTimesAchievement sleepAchievement = new SleepMultipleTimesAchievement();

    @Test
    public void testFirstTimeSlept() {
        assertFalse(sleptOnce.isUnlocked());
        assertEquals(0, sleptOnce.getCurrentProgress());
        assertEquals(0, sleptOnce.getCurrentLevel());
        assertEquals(1, sleptOnce.getMaxLevel());
        assertEquals("Wooden", sleptOnce.getCurrentBadge());
        sleptOnce.setCurrentProgress(sleptOnce.getMilestones()[0]-1);
        sleptOnce.incrementProgress();
        assertTrue(sleptOnce.isUnlocked());
        assertEquals("Diamond", sleptOnce.getCurrentBadge());
    }

    @Test
    public void testSleepMultipleTimesAchievementsInitialisation() {
        assertFalse(sleepAchievement.isUnlocked());
        assertEquals(0, sleepAchievement.getCurrentProgress());
        assertEquals(0, sleepAchievement.getCurrentLevel());
        assertEquals(4, sleepAchievement.getMaxLevel());
        assertEquals("Wooden", sleepAchievement.getCurrentBadge());
    }

    @Test
    public void testSleepAchievementsLevel1() {
        sleepAchievement.setCurrentProgress(sleepAchievement.getMilestones()[0]-1);
        sleepAchievement.incrementProgress();
        assertTrue(sleepAchievement.isUnlocked());
        assertEquals("Bronze", sleepAchievement.getCurrentBadge());

    }

    @Test
    public void testSleepAchievementsLevel2() {
        sleepAchievement.checkProgress(sleepAchievement.getMilestones()[1]-1);
        sleepAchievement.incrementProgress();
        assertEquals("Silver", sleepAchievement.getCurrentBadge());
    }

    @Test
    public void testSleepAchievementsLevel3() {
        sleepAchievement.checkProgress(sleepAchievement.getMilestones()[2]);
        sleepAchievement.incrementProgress();
        sleepAchievement.incrementProgress();
        assertEquals("Gold", sleepAchievement.getCurrentBadge());
    }

    @Test
    public void testSleepAchievementsLevel4() {
        sleepAchievement.checkProgress(sleepAchievement.getMilestones()[3]-1);
        sleepAchievement.incrementProgress();
        sleepAchievement.incrementProgress();
        sleepAchievement.incrementProgress();
        assertEquals("Diamond", sleepAchievement.getCurrentBadge());
    }
}