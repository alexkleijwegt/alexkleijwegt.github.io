package com.skloch.game.AchievementSystem.Achievements;

public class FirstTimeStudiedAchievement extends Achievements {

    public FirstTimeStudiedAchievement() {
        super("First Time Studied", "Study for the first time!", new int[]{1});
    }
}
