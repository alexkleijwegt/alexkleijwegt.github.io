package com.skloch.game.tests;

import com.skloch.game.GameOverScreen;

public class GameOverScreenFake {
    int Score = 0;
    public GameOverScreenFake(int hoursStudied, int hoursRecreational, int hoursSlept){
        Score = calculateScore(hoursStudied,hoursRecreational,hoursSlept);
    }

    public int calculateScore(int hoursStudied, int hoursRecreational, int hoursSlept) {
        int score = 0;
        if (hoursSlept >= 50 && hoursSlept < 70){ //slept a good amount
            score += hoursSlept - 10;
        }
        else if (hoursSlept < 50){  //not enough sleep
            score += hoursSlept / 2;
        }
        else{  //too much sleep
            score += 80 - (hoursSlept - 80);
        }

        if (hoursStudied >= 30 && hoursStudied < 50){ //Studied a good amount
            score += hoursStudied + 20;
        }
        else if (hoursStudied < 30){  //not enough Studying
            score += hoursStudied / 2;
        }
        else{  //too much Studying
            score += 50 - (hoursStudied - 50);
        }

        if (hoursRecreational >= 30 && hoursRecreational < 50){ //relaxed a good amount
            score += hoursRecreational;
        }
        else if (hoursRecreational < 30){  //not enough relaxing
            score += hoursRecreational / 2;
        }
        else{  //too much relaxing
            score += 50 - (hoursRecreational - 50);
        }
        return score;
    }

    public int getScore() {return Score;}

}
