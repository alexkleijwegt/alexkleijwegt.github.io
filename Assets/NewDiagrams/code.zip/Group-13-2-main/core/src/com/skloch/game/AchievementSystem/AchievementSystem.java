package com.skloch.game.AchievementSystem;

import com.skloch.game.AchievementSystem.Achievements.*;

import java.util.ArrayList;

/**
 * To use the Achievement System somewhere, use AchievementSystem.getInstance();
 * The achievement system is a singleton so it is accessible everywhere.
 */
public class AchievementSystem {
    private static AchievementSystem instance;

    private final Achievements firstTimeEatenAchievement;
    private final Achievements eatMultipleTimesAchievement;

    private final Achievements firstTimeSleptAchievement;
    private final Achievements sleepMultipleTimesAchievement;

    private final Achievements firstTimeRecreationAchievement;
    private final Achievements recreationalMultipleTimesAchievement;

    private final Achievements firstTimeStudiedAchievement;
    private final Achievements studyMultipleTimesAchievement;

    private final Achievements distanceTraveledAchievement;

    private final ArrayList<Achievements> Achievementslist = new ArrayList<Achievements>();

    public AchievementSystem() {
        firstTimeEatenAchievement = new FirstTimeEatenAchievement();
        eatMultipleTimesAchievement = new EatMultipleTimesAchievement();

        firstTimeSleptAchievement = new FirstTimeSleptAchievement();
        sleepMultipleTimesAchievement = new SleepMultipleTimesAchievement();

        firstTimeRecreationAchievement = new FirstTimeRecreationAchievement();
        recreationalMultipleTimesAchievement = new RecreationalMultipleTimesAchievement();

        firstTimeStudiedAchievement = new FirstTimeStudiedAchievement();
        studyMultipleTimesAchievement = new StudyMultipleTimesAchievement();

        distanceTraveledAchievement = new DistanceTraveledAchievement();

        Achievementslist.add(firstTimeEatenAchievement);
        Achievementslist.add(eatMultipleTimesAchievement);
        Achievementslist.add(firstTimeSleptAchievement);
        Achievementslist.add(sleepMultipleTimesAchievement);
        Achievementslist.add(firstTimeRecreationAchievement);
        Achievementslist.add(recreationalMultipleTimesAchievement);
        Achievementslist.add(firstTimeStudiedAchievement);
        Achievementslist.add(studyMultipleTimesAchievement);
        Achievementslist.add(distanceTraveledAchievement);
    }

    /**
     * @return Returns the same achievement system everywhere.
     */
    public static AchievementSystem getInstance() {
        if (instance == null) {
            instance = new AchievementSystem();
        }
        return instance;
    }

    public ArrayList<Achievements> getCompletedAchievements() {
        ArrayList<Achievements> completed = new ArrayList<Achievements>();

        //getFirstTimeEatenAchievement().setUnlocked(true);
        //uncomment above line to test achievement display

        for (int i = 0; i < this.Achievementslist.size(); i++) {
            if (this.Achievementslist.get(i).isUnlocked()) {
                completed.add(this.Achievementslist.get(i));
            }
        }

        return completed;
    }

    public void resetAchievements(){
        for (int i = 0; i < this.Achievementslist.size(); i++) {
            this.Achievementslist.get(i).reset();
        }
    }

    public void addAchievement(Achievements achievement) {
        this.Achievementslist.add(achievement);
    }

    public Achievements getFirstTimeEatenAchievement() {
        return this.firstTimeEatenAchievement;
    }

    public Achievements getEatMultipleTimesAchievement() {
        return this.eatMultipleTimesAchievement;
    }

    public Achievements getFirstTimeSleptAchievement() {
        return this.firstTimeSleptAchievement;
    }

    public Achievements getSleepMultipleTimesAchievement() {
        return this.sleepMultipleTimesAchievement;
    }

    public Achievements getFirstTimeRecreationAchievement() {
        return this.firstTimeRecreationAchievement;
    }

    public Achievements getRecreationalMultipleTimesAchievement() {
        return this.recreationalMultipleTimesAchievement;
    }

    public Achievements getFirstTimeStudiedAchievement() {
        return this.firstTimeStudiedAchievement;
    }

    public Achievements getStudyMultipleTimesAchievement() {
        return this.studyMultipleTimesAchievement;
    }

    public Achievements getDistanceTraveledAchievement() {
        return this.distanceTraveledAchievement;
    }
}
