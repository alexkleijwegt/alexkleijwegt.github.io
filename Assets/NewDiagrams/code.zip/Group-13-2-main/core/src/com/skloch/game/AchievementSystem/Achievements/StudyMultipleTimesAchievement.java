package com.skloch.game.AchievementSystem.Achievements;

public class StudyMultipleTimesAchievement extends Achievements {
    public StudyMultipleTimesAchievement() {
        super("Study Multiple Times", "Study multiple times!", new int[]{3, 5, 8, 12});
    }
}