package com.skloch.game.AchievementSystem.Achievements;

public class EatMultipleTimesAchievement extends Achievements {

    public EatMultipleTimesAchievement() {
        super("Eat Multiple Times", "Eat multiple times!", new int[]{3, 5, 8, 12});
    }
}
