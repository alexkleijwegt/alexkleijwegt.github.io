package com.skloch.game.AchievementSystem.Achievements;

public class FirstTimeEatenAchievement extends Achievements {

    public FirstTimeEatenAchievement() {
        super("First Time Eaten", "Eat something for the first time!", new int[]{1});
    }
}
