package com.skloch.game.AchievementSystem.Achievements;


public abstract class Achievements implements IAchievements {
    protected String name;
    protected String description;
    protected boolean unlocked;
    protected int currentProgress;
    protected int lastProcessedProgress = 0;
    protected int[] milestones;
    protected int maxLevel;
    protected int currentLevel;
    protected String[] possibleBadges = {"Wooden", "Bronze", "Silver", "Gold", "Diamond"};
    protected String currentBadge;
    // Add a variable for the picture if needed

    /**
     * Automatically sets unlocked to false as all achievements start locked.
     * Sets current progress to 0 as you shouldn't have any progress when you start.
     * Sets maxLevel to the size of milestones.
     * If the achievement has 1 level, make an array of 1 element.
     *
     * @param name        Name of the achievement.
     * @param description Description of the achievement
     * @param milestones  Set milestones for the achievement.
     */
    protected Achievements(String name, String description, int[] milestones) {
        this.name = name;
        this.description = description;
        this.unlocked = false;

        this.currentProgress = 0;
        this.milestones = milestones;

        this.currentLevel = 0;
        this.maxLevel = this.milestones.length;
        this.updateBadge();
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public boolean isUnlocked() {
        return unlocked;
    }

    public void setUnlocked(boolean unlocked) {
        this.unlocked = unlocked;
    }

    public int getCurrentProgress() {
        return currentProgress;
    }

    public void setCurrentProgress(int currentProgress) {
        this.currentProgress = currentProgress;
    }

    public int[] getMilestones() {
        return milestones;
    }

    public int getMaxLevel() {
        return maxLevel;
    }

    public int getCurrentLevel() {
        return currentLevel;
    }

    public String getCurrentBadge() {
        return currentBadge;
    }

    /**
     * Determines the appropriate badge based on the current level of the achievement.
     */
    private void updateBadge() {
        int badgeIndex;

        switch (maxLevel) {
            case 1:
                badgeIndex = currentLevel == 0 ? 0 : possibleBadges.length - 1;
                break;
            case 2:
                badgeIndex = currentLevel == 0 ? 0 : currentLevel == 1 ? 2 : possibleBadges.length - 1;
                break;
            case 3:
                badgeIndex = currentLevel == 0 ? 0 : currentLevel == 1 ? 1 : currentLevel == 2 ? 3 : possibleBadges.length - 1;
                break;
            default:
                badgeIndex = currentLevel;
                break;
        }

        currentBadge = possibleBadges[badgeIndex];
    }

    /**
     * Increments the progress for the achievement.
     * If the achievement is at or past the set milestone, updates the level and badge accordingly.
     */
    @Override
    public void incrementProgress() {
        currentProgress++;
        if (currentLevel < maxLevel && currentProgress >= milestones[currentLevel]) {
            currentLevel++;
            this.setUnlocked(true);
            System.out.println(this.name + " has achieved " + currentLevel + " milestones.");
            updateBadge();
        }
    }

    public void checkProgress(int currentProgress) {
        if (currentProgress > this.currentProgress) {
            this.currentProgress = currentProgress;
            incrementProgress();
        }
    }

    // Implement any other common methods for achievements
    public void reset(){
        this.unlocked = false;
        this.currentProgress = 0;
        this.currentLevel = 0;
        this.updateBadge();
    }
}
