<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Ducks" tilewidth="24" tileheight="24" tilecount="2" columns="2">
 <image source="../Textures/Ducks.png" width="48" height="24"/>
</tileset>
