<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="SportsCentre" tilewidth="24" tileheight="24" tilecount="416" columns="32">
 <image source="../Textures/SportsCentre.png" width="783" height="323"/>
</tileset>
