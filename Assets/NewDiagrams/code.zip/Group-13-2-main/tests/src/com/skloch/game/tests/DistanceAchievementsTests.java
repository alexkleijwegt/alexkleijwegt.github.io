package com.skloch.game.tests;

import com.skloch.game.AchievementSystem.Achievements.DistanceTraveledAchievement;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(GdxTestRunner.class)
public class DistanceAchievementsTests {
    DistanceTraveledAchievement distanceAchievement = new DistanceTraveledAchievement();

    @Test
    public void testDistanceAchievementsInitialisation() {
        DistanceTraveledAchievement distanceAchievement = new DistanceTraveledAchievement();
        assertFalse(distanceAchievement.isUnlocked());
        assertEquals(0, distanceAchievement.getCurrentProgress());
        assertEquals(0, distanceAchievement.getCurrentLevel());
        assertEquals(4, distanceAchievement.getMaxLevel());
        assertEquals("Wooden", distanceAchievement.getCurrentBadge());
    }

    @Test
    public void testDistanceAchievementsLevel1() {
        distanceAchievement.setCurrentProgress(distanceAchievement.getMilestones()[0]-1);
        distanceAchievement.incrementProgress();
        assertTrue(distanceAchievement.isUnlocked());
        assertEquals("Bronze", distanceAchievement.getCurrentBadge());

    }

    @Test
    public void testDistanceAchievementsLevel2() {
        distanceAchievement.checkProgress(distanceAchievement.getMilestones()[1]-1);
        distanceAchievement.incrementProgress();
        assertEquals("Silver", distanceAchievement.getCurrentBadge());
    }

    @Test
    public void testDistanceAchievementsLevel3() {
        distanceAchievement.checkProgress(distanceAchievement.getMilestones()[2]);
        distanceAchievement.incrementProgress();
        distanceAchievement.incrementProgress();
        assertEquals("Gold", distanceAchievement.getCurrentBadge());
    }

    @Test
    public void testDistanceAchievementsLevel4() {
        distanceAchievement.checkProgress(distanceAchievement.getMilestones()[3]-1);
        distanceAchievement.incrementProgress();
        distanceAchievement.incrementProgress();
        distanceAchievement.incrementProgress();
        assertEquals("Diamond", distanceAchievement.getCurrentBadge());
    }
}
