# Heslington Hustle Group 16 - Group 13
Group 13's updates to Group 16's of Heslington Hustle

[Website](https://samh366.github.io/index.html) |
[Javadocs](https://samh366.github.io/Assets/Project%20Javadoc/com/skloch/game/package-summary.html) |
[Latest Release](https://github.com/what2208/Game-Project-Group-16-/releases/latest)

**If making changes to the code, please see the documentation:**

[Documentation](https://docs.google.com/document/d/e/2PACX-1vSv_ceo9WVWkExVdJTcRDvOGG9dvaT4u3FKtMxP3KHxWDgZjG1YxPeSrSR09Ll2qwSzs-jig_dpa5-k/pub)

Our group name is SKLOCH, it's the first letter of everyone's name in the group
