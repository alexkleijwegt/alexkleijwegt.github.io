package com.skloch.game.AchievementSystem.Achievements;

public interface IAchievements {

    // Returns name
    String getName();

    // Returns description
    String getDescription();

    // Returns whether it is unlocked
    boolean isUnlocked();

    // Locks/Unlocks achievement
    void setUnlocked(boolean unlocked);

    // Shows current progress
    int getCurrentProgress();

    // Sets current progress
    void setCurrentProgress(int currentProgress);

    // Increments progress
    void incrementProgress();

    // Returns all milestones
    int[] getMilestones();

    // Returns max level
    int getMaxLevel();

    // Returns current level
    int getCurrentLevel();

}
