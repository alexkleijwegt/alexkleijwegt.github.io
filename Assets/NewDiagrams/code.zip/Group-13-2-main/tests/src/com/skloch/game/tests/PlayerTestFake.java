package com.skloch.game.tests;
import com.skloch.game.GameObject;
import com.skloch.game.Player;

public class PlayerTestFake extends Player {


    /**
     * A player character, contains methods to move the player and update animations, also includes collision handling
     * and can be used to trigger events of objects near the player.
     * Includes a feet hitbox for collision and an event hitbox for triggering objects.
     * Call move() then draw the result of getCurrentAnimation() to use
     *
     * @param avatar "avatar1" for the more masculine character, "avatar2" for the more feminine character,
     *               player animations are packed in the player_sprites atlas
     */
    public PlayerTestFake(String avatar) {
        super(avatar);
    }


    public void move(int delta, boolean left, boolean right, boolean up, boolean down){

        moving = false;
        // To check collision, store the player's current position
        float oldX = sprite.x;
        float oldY = sprite.y;
        float oldFeetX = feet.x;

        // If not frozen, react to keyboard input presses
        if (!frozen) {
            // Move the player and their 2 other hitboxes
            moving = false;
            if (left) {
                this.setX(sprite.getX() - speed * delta); // Note: Setting all the values with a constant delta removes hitbox desyncing issues
                direction = 3;
                moving = true;
            }
            if (right) {
                this.setX(sprite.getX() + speed * delta);
                direction = 1;
                moving = true;
            }
            if (up) {
                this.setY(sprite.getY() + speed * delta);
                direction = 0;
                moving = true;
            }
            if (down) {
                this.setY(sprite.getY() - speed * delta);
                direction = 2;
                moving = true;
            }

            // Check if the player's feet are inside an object, if they are, move them back in that axis
            for (GameObject object : this.collidables) {
                if (feet.overlaps(object)) {
                    // Find the direction that the player needs to be moved back to
                    // Reset x
                    if (!(oldFeetX < object.x + object.width && oldFeetX + feet.width > object.x)) {
                        this.setX(oldX);
                    }
                    // If overlapping in y direction
                    if (!(oldY < object.y + object.height && oldY + feet.height > object.y)) {
                        this.setY(oldY);
                    }
                    // The above two are essentially the same code as Rectangle.overlaps()
                    // Just separated into the x and y dimensions
                }
            }
        }
    }
}
