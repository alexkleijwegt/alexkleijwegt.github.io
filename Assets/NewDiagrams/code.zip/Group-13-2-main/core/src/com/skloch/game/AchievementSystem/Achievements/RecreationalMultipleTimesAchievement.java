package com.skloch.game.AchievementSystem.Achievements;

public class RecreationalMultipleTimesAchievement extends Achievements {
    public RecreationalMultipleTimesAchievement() {
        super("Recreational Multiple Times", "Perform recreational activities multiple times!", new int[]{2, 4, 7, 10});
    }
}