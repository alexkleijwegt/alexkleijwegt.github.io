package com.skloch.game.tests;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.skloch.game.ScoreSystem;

import java.util.Map;

import static org.junit.Assert.assertEquals;

@RunWith(GdxTestRunner.class)
public class ScoreSystemTests {
    final float DELTA = 0.001f;
        @Test
    public void testIncrementSleep() {
        String activity = "Sleep";
        ScoreSystem score = ScoreSystem.getInstance();
        Map<String, Float> totalScores = score.getActivityTotalScores();
        Map<String, Float> totalCounts = score.getActivityCounts();
        assertEquals(0f, totalScores.get(activity), DELTA);
        assertEquals(0f, totalCounts.get(activity), DELTA);
        score.incrementActivity(activity, 100f, "Wooden", 4, 1);
        assertEquals(100f, totalScores.get(activity), DELTA);
        assertEquals(1f, totalCounts.get(activity), DELTA);
    }

    @Test
    public void testIncrementEat() {
        String activity = "Eat";
        ScoreSystem score = ScoreSystem.getInstance();
        Map<String, Float> totalScores = score.getActivityTotalScores();
        Map<String, Float> totalCounts = score.getActivityCounts();
        assertEquals(0f, totalScores.get(activity), DELTA);
        assertEquals(0f, totalCounts.get(activity), DELTA);
        score.incrementActivity(activity, 100f, "Wooden", 4, 1);
        assertEquals(100f, totalScores.get(activity), DELTA);
        assertEquals(1f, totalCounts.get(activity), DELTA);
    }

    @Test
    public void testIncrementStudy() {
        String activity = "Study";
        ScoreSystem score = ScoreSystem.getInstance();
        Map<String, Float> totalScores = score.getActivityTotalScores();
        Map<String, Float> totalCounts = score.getActivityCounts();
        assertEquals(0f, totalScores.get(activity), DELTA);
        assertEquals(0f, totalCounts.get(activity), DELTA);
        score.incrementActivity(activity, 100f, "Wooden", 4, 1);
        assertEquals(100f, totalScores.get(activity), DELTA);
        assertEquals(1f, totalCounts.get(activity), DELTA);
    }

    @Test
    public void testIncrementFun() {
        String activity = "Fun";
        ScoreSystem score = ScoreSystem.getInstance();
        Map<String, Float> totalScores = score.getActivityTotalScores();
        Map<String, Float> totalCounts = score.getActivityCounts();
        assertEquals(0f, totalScores.get(activity), DELTA);
        assertEquals(0f, totalCounts.get(activity), DELTA);
        score.incrementActivity(activity, 100f, "Wooden", 4, 1);
        assertEquals(100f, totalScores.get(activity), DELTA);
        assertEquals(1f, totalCounts.get(activity), DELTA);
    }

}
