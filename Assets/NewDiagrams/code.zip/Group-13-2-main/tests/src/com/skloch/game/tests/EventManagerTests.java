package com.skloch.game.tests;

import com.skloch.game.EventManager;
import com.skloch.game.GameScreen;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)

public class EventManagerTests {

    @Mock
    private GameScreen screen;

    @InjectMocks
    private EventManager eventManager;

    @Before
    public void setup() {
    }
    @Test
    public void testInstantiated() {
        assertNotNull(eventManager.activityEnergies);
        int studyEnergy = eventManager.activityEnergies.get("studying");
        assertEquals(10, studyEnergy);
        int friendEnergy = eventManager.activityEnergies.get("meet_friends");
        assertEquals(10, friendEnergy);
        int eatEnergy = eventManager.activityEnergies.get("eating");
        assertEquals(10, eatEnergy);
    }
}
