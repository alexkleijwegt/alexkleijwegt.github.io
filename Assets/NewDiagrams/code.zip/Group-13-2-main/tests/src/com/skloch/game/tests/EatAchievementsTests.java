package com.skloch.game.tests;
import com.skloch.game.AchievementSystem.Achievements.EatMultipleTimesAchievement;
import com.skloch.game.AchievementSystem.Achievements.FirstTimeEatenAchievement;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(GdxTestRunner.class)
public class EatAchievementsTests {
    FirstTimeEatenAchievement eatOnce = new FirstTimeEatenAchievement();
    EatMultipleTimesAchievement eatAchievement = new EatMultipleTimesAchievement();

    @Test
    public void testFirstTimeAte() {
        assertFalse(eatOnce.isUnlocked());
        assertEquals(0, eatOnce.getCurrentProgress());
        assertEquals(0, eatOnce.getCurrentLevel());
        assertEquals(1, eatOnce.getMaxLevel());
        assertEquals("Wooden", eatOnce.getCurrentBadge());
        eatOnce.setCurrentProgress(eatOnce.getMilestones()[0]-1);
        eatOnce.incrementProgress();
        assertTrue(eatOnce.isUnlocked());
        assertEquals("Diamond", eatOnce.getCurrentBadge());
    }

    @Test
    public void testEatMultipleTimesAchievementsInitialisation() {
        assertFalse(eatAchievement.isUnlocked());
        assertEquals(0, eatAchievement.getCurrentProgress());
        assertEquals(0, eatAchievement.getCurrentLevel());
        assertEquals(4, eatAchievement.getMaxLevel());
        assertEquals("Wooden", eatAchievement.getCurrentBadge());
    }

    @Test
    public void testEatAchievementsLevel1() {
        eatAchievement.setCurrentProgress(eatAchievement.getMilestones()[0]-1);
        eatAchievement.incrementProgress();
        assertTrue(eatAchievement.isUnlocked());
        assertEquals("Bronze", eatAchievement.getCurrentBadge());

    }

    @Test
    public void testEatAchievementsLevel2() {
        eatAchievement.checkProgress(eatAchievement.getMilestones()[1]-1);
        eatAchievement.incrementProgress();
        assertEquals("Silver", eatAchievement.getCurrentBadge());
    }

    @Test
    public void testEatAchievementsLevel3() {
        eatAchievement.checkProgress(eatAchievement.getMilestones()[2]);
        eatAchievement.incrementProgress();
        eatAchievement.incrementProgress();
        assertEquals("Gold", eatAchievement.getCurrentBadge());
    }

    @Test
    public void testEatAchievementsLevel4() {
        eatAchievement.checkProgress(eatAchievement.getMilestones()[3]-1);
        eatAchievement.incrementProgress();
        eatAchievement.incrementProgress();
        eatAchievement.incrementProgress();
        assertEquals("Diamond", eatAchievement.getCurrentBadge());
    }
}