package com.skloch.game.tests;
import com.skloch.game.AchievementSystem.Achievements.FirstTimeRecreationAchievement;
import com.skloch.game.AchievementSystem.Achievements.RecreationalMultipleTimesAchievement;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(GdxTestRunner.class)
public class RecreationAchievementsTests {
    FirstTimeRecreationAchievement recOnce = new FirstTimeRecreationAchievement();
    RecreationalMultipleTimesAchievement recAchievement = new RecreationalMultipleTimesAchievement();

    @Test
    public void testFirstTimeRec() {
        assertFalse(recOnce.isUnlocked());
        assertEquals(0, recOnce.getCurrentProgress());
        assertEquals(0, recOnce.getCurrentLevel());
        assertEquals(1, recOnce.getMaxLevel());
        assertEquals("Wooden", recOnce.getCurrentBadge());
        recOnce.setCurrentProgress(recOnce.getMilestones()[0]-1);
        recOnce.incrementProgress();
        assertTrue(recOnce.isUnlocked());
        assertEquals("Diamond", recOnce.getCurrentBadge());
    }

    @Test
    public void testRecMultipleTimesAchievementsInitialisation() {
        assertFalse(recAchievement.isUnlocked());
        assertEquals(0, recAchievement.getCurrentProgress());
        assertEquals(0, recAchievement.getCurrentLevel());
        assertEquals(4, recAchievement.getMaxLevel());
        assertEquals("Wooden", recAchievement.getCurrentBadge());
    }

    @Test
    public void testRecAchievementsLevel1() {
        recAchievement.setCurrentProgress(recAchievement.getMilestones()[0]-1);
        recAchievement.incrementProgress();
        assertTrue(recAchievement.isUnlocked());
        assertEquals("Bronze", recAchievement.getCurrentBadge());

    }

    @Test
    public void testRecAchievementsLevel2() {
        recAchievement.checkProgress(recAchievement.getMilestones()[1]-1);
        recAchievement.incrementProgress();
        assertEquals("Silver", recAchievement.getCurrentBadge());
    }

    @Test
    public void testRecAchievementsLevel3() {
        recAchievement.checkProgress(recAchievement.getMilestones()[2]);
        recAchievement.incrementProgress();
        recAchievement.incrementProgress();
        assertEquals("Gold", recAchievement.getCurrentBadge());
    }

    @Test
    public void testRecAchievementsLevel4() {
        recAchievement.checkProgress(recAchievement.getMilestones()[3]-1);
        recAchievement.incrementProgress();
        recAchievement.incrementProgress();
        recAchievement.incrementProgress();
        assertEquals("Diamond", recAchievement.getCurrentBadge());
    }
}