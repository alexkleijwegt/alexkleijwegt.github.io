package com.skloch.game.tests;

import com.skloch.game.EventManager;
import com.skloch.game.GameScreen;

public class EventManagerFake extends EventManager {
    /**
     * A class that maps Object's event strings to actual Java functions.
     * To run a function call event(eventString), to add arguments add dashes.
     * E.g. a call to the Piazza function with an arg of 1 would be: "piazza-1"
     * Which the function interprets as "study at the piazza for 1 hour".
     * Object's event strings can be set in the Tiled map editor with a property called "event"
     *
     * @param game An instance of the GameScreen containing a player and dialogue box
     */

    public int seconds;
    public EventManagerFake(GameScreen game, int seconds) {
        super(game);
        this.seconds = seconds;

    }

    @Override
    public void event(String eventKey) {
        String[] args = eventKey.split("-");

        // Important functions, most likely called after displaying text
        if (args[0].equals("fadefromblack")) {
            fadeFromBlack();
        } else if (args[0].equals("fadetoblack")) {
            fadeToBlack();
        } else if (args[0].equals("gameover")) {
            gameOver();
        }

        // Events related to objects
        switch (args[0]) {
            case "tree":
                treeEvent();
                break;
            case "chest":
                chestEvent();
                break;
            case "piazza":
                piazzaEvent(args);
                break;
            case "comp_sci":
                compSciEvent(args);
                break;
            case "rch":
                ronCookeEvent(args);
                break;
            case "accomodation":
                accomEvent(args);
                break;
            case "west_travel":
                westtravelEvent(args);
                break;
            case "east_travel":
                easttravelEvent(args);
                break;
            case "library":
                libraryEvent(args);
                break;
            case "sports_centre":
                sportscentreEvent(args);
                break;
            case "ducks":
                duckEvent(args);
                break;
            case "nisa":
                nisaEvent(args);
                break;
            case "longboi":
                longboiEvent(args);
                break;

            case "exit":
                // Should do nothing and just close the dialogue menu
                gameOver();
                break;
            default:
                objectEvent(eventKey);
                break;

        }

    }

    public String gameOver() {return "Game Over";}


}
