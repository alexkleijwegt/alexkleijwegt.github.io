package com.skloch.game.tests;
import com.skloch.game.GameOverScreen;
import com.skloch.game.HustleGame;
import com.skloch.game.SoundManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

@RunWith(GdxTestRunner.class)
public class GameOverScreenTests {
    @Test
    public void testScoreSleptJustEnough() {
        GameOverScreenFake gameOverScreen = new GameOverScreenFake(40, 40, 50);
        assertEquals(140, gameOverScreen.getScore());
    }

    @Test
    public void testScoreStudiedJustEnough() {
        GameOverScreenFake gameOverScreen = new GameOverScreenFake(30, 40, 60);
        assertEquals(140, gameOverScreen.getScore());
    }

    @Test
    public void testScoreRelaxedJustEnough() {
        GameOverScreenFake gameOverScreen = new GameOverScreenFake(40, 30, 60);
        assertEquals(140, gameOverScreen.getScore());
    }

    @Test
    public void testScoreSleptJustNotEnough() {
        GameOverScreenFake gameOverScreen = new GameOverScreenFake(40, 40, 49);
        assertEquals(124, gameOverScreen.getScore());
    }

    @Test
    public void testScoreStudiedJustNotEnough() {
        GameOverScreenFake gameOverScreen = new GameOverScreenFake(29, 40, 60);
        assertEquals(104, gameOverScreen.getScore());
    }

    @Test
    public void testScoreRelaxedJustNotEnough() {
        GameOverScreenFake gameOverScreen = new GameOverScreenFake(40, 29, 60);
        assertEquals(124, gameOverScreen.getScore());
    }

    @Test
    public void testScoreSleptTooMuch() {
        GameOverScreenFake gameOverScreen = new GameOverScreenFake(40, 40, 70);
        assertEquals(190, gameOverScreen.getScore());
    }

    @Test
    public void testScoreStudiedTooMuch() {
        GameOverScreenFake gameOverScreen = new GameOverScreenFake(50, 40, 60);
        assertEquals(140, gameOverScreen.getScore());
    }

    @Test
    public void testScoreRelaxedTooMuch() {
        GameOverScreenFake gameOverScreen = new GameOverScreenFake(40, 50, 60);
        assertEquals(160, gameOverScreen.getScore());
    }


}
