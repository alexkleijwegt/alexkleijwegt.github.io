package com.skloch.game.tests;
import com.skloch.game.HustleGame;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(GdxTestRunner.class)
public class HustleGameTests {
    @Test
    public void testGameInitalisesCorrectly() {
        int expectedWidth = 600;
        int expectedHeight = 900;
        HustleGame game = new HustleGame(expectedWidth, expectedHeight);
        assertEquals(expectedWidth, game.WIDTH);
        assertEquals(expectedHeight, game.HEIGHT);
    }
}
